import pexpect

def module3():
 print("This is the inner packmodule package")

__all__ = [
    'module3'
]


